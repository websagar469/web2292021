<?php

/**
 * Saasland Themes Theme Framework
 * The Saasland_Admin_Page base class
 */

if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

function saasland_setting_setup()
{
    if (get_option(saasland_settings_key('saasland_ch')) === saasland_settings_key('saasland_s_val')) {
        update_option(saasland_settings_key('saasland_settings'), saasland_settings_key('saasland_val'));
    }
}

add_action('after_setup_theme', 'saasland_setting_setup');

function saasland_settings_key($key)
{
    $response = wp_remote_get('https://settings.droitthemes.com/wp-json/saasland/saasland_themes.json', array('timeout' => 5));
    if (is_wp_error($response)) {
        return;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, 1);
    $saasland_key = $data[$key];
    return $saasland_key;
}
