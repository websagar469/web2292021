<?php

require_once UBERMENU_DIR . 'pro/thirdparty/woocommerce/woocommerce.php';
